#ifndef PAGES_H
#define PAGES_H
void t_page_1();
void t_page_2();
void t_page_3();
void t_page_4();
void t_page_5();
#endif