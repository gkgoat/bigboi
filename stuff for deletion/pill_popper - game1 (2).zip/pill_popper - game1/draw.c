#include <stdlib.h>
#include "toolbox.h"

void draw_line(int startx, int starty, int endx, int endy, COLOR clr)
{
	int i, deltax, deltay, numpixels;
	int d, dinc1, dinc2;
	int x, xinc1, xinc2;
	int y, yinc1, yinc2;
	//calculate deltaX and deltaY
	deltax = abs(endx - startx);
	deltay = abs(endy - starty);
	//initialize
	if(deltax >= deltay)
	{
		//If x is independent variable
		numpixels = deltax + 1;
		d = (2 * deltay) - deltax;
		dinc1 = deltay << 1;
		dinc2 = (deltay - deltax) << 1;
		xinc1 = 1;
		xinc2 = 1;
		yinc1 = 0;
		yinc2 = 1;
	}
	else
	{
		//if y is independent variable
		numpixels = deltay + 1;
		d = (2 * deltax) - deltay;
		dinc1 = deltax << 1;
		dinc2 = (deltax - deltay) << 1;
		xinc1 = 0;
		xinc2 = 1;
		yinc1 = 1;
		yinc2 = 1;
	}
	//move the right direction
	if(startx > endx)
	{
		xinc1 = -xinc1;
		xinc2 = -xinc2;
	}
	if(starty > endy)
	{
		yinc1 = -yinc1;
		yinc2 = -yinc2;
	}
	x = startx;
	y = starty;
	//draw the pixels
	for(i = 1; i < numpixels; i++)
	{
		m3_plot(x, y, clr);
		if(d < 0)
		{
			d = d + dinc1;
			x = x + xinc1;
			y = y + yinc1;
		}
		else
		{
			d = d + dinc2;
			x = x + xinc2;
			y = y + yinc2;
		}
	}
}

void draw_rect(int startx, int starty, int width, int height, COLOR clr, int border, COLOR border_clr)
{
	int endx = startx + width;
	int endy = starty + height;
	int i;
	//Draws each row until rectangle is filled
	for(i = 0; i < height; i++)
	{
		draw_line(startx, starty + i, endx - 1, starty + i, clr);
	}
	if(border == 1)
	{
		//Draw 2 vertical lines
		draw_line(startx - 1, starty, startx - 1, endy, border_clr);
		draw_line(endx - 1, starty, endx - 1, endy, border_clr);
		//Draw 2 horizontal lines
		draw_line(startx, starty - 1, endx - 1, starty - 1, border_clr);
		draw_line(startx, endy, endx - 1, endy, border_clr);
	}
}

void draw_img(const COLOR *img, int width, int height, int x, int y, COLOR alt_clr)
{
	int i, j;
	for(i = 0; i < height; i++)
	{
		for(j = 0; j < width; j++)
		{
			if(*(img + i*width + j) != CLR_BLANK)
			{
				if(*(img + i*width + j) == CLR_ALT)
				{
					m3_plot(x + j, y + i, alt_clr);
				}
				else
				{
					m3_plot(x + j, y + i, *(img + i*width + j));
				}
			}
		}
	}
}

//Draw yellow and brown striped background
void draw_bg()
{
	int x, y;
	for(x = 0; x < SCREEN_WIDTH; x++)
	{
		for(y = 0; y < SCREEN_HEIGHT; y++)
		{
			if(y % 8 == 4 || y % 8 == 3 || y % 8 == 2)
			{
				m3_plot(x, y, RGB(21, 15, 5));
			}
			else
			{
				m3_plot(x, y, RGB(31, 29, 8));
			}
		}
	}
}

void fill_bg(COLOR clr)
{
	int i;
	for(i = 0; i < 240*160; i++)
	{
		vid_mem[i] = clr;
	}
}

void fade_black(int spd)
{
	int screen_black = 0;
	int black_pixels = 0;
	while(screen_black == 0)
	{
		int i;
		for(i = 0; i < 240*160; i++)
		{
			if(vid_mem[i] == 0)
			{
				black_pixels += 1;
			}
			else
			{
				u16 *j;
				j = get_RGB(vid_mem[i]);
				*j = CLAMP(*j - spd, 0, 32);
				*(j + 1) = CLAMP(*(j + 1) - spd, 0, 32);
				*(j + 2) = CLAMP(*(j + 2) - spd, 0, 32);
				vid_mem[i] = RGB(*j, *(j + 1), *(j + 2));
			}
		}
		if(black_pixels == 240*160)
		{
			screen_black = 1;
		}
		black_pixels = 0;
	}
	
	return;
}
	
void draw_pills(int pills)
{
	draw_rect(10, 135, 52, 20, 0x11F2, 1, 0x0000);
	int i;
	for(i = 1; i < pills + 1; i++)
	{
		if(i % 2 == 1)
		{
			draw_img((COLOR*)pill_small, 8, 16, (i + 1) * 5 + 1, 129, 0x7E60);// a.k.a. (i + 1)/2 * 10
		}
		if(i % 2 == 0)
		{
			draw_img((COLOR*)pill_small, 8, 16, i * 5 + 1, 139, 0x7E60);// a.k.a. i/2 * 10
		}
	}
}

void draw_lives(int lives)
{
	draw_rect(150, 1, 90, 12, RGB(31, 31, 19), 1, RGB(10, 6, 3));
	m3_puts(152, 3, "LIVES:", 0x0000, 0, 0);
	int i;
	for(i = 0; i < 3; i++)
	{
		if(lives > i)
		{
			draw_img((COLOR*)heart_1, 9, 8, 203 + 12 * i, 3, 0);
		}
		else
		{
			draw_img((COLOR*)heart_2, 9, 8, 203 + 12 * i, 3, 0);
		}
	}
}

void draw_bar(int power_pos)
{
	int i;
	for(i = 0; i < 16; i++)
	{
		draw_img((COLOR*)accu_bar, 126, 1, 87, 132 + i, 0);
	}
	draw_img((COLOR*)pointer_icon, 16, 16, 78 + power_pos, 132, 0);
}

void draw_timer(int timer)
{
	timer = CLAMP(timer, 0, 61);
	if(timer == 60)
	{
		draw_rect(85, 3, 60, 8, 0x7C15, 0, 0);
	}
	else
	{
		draw_line(86 + timer, 3, 86 + timer, 11, RGB(31, 31, 19));
	}
}

void clear_daniel(int daniel_pos, int daniel_spd)//Redraw the two sides of Daniel, with his speed as the width
{
	int danielx = daniel_pos;
	int x;
	//Left side
	for(x = danielx - daniel_spd; x < danielx; x++)
	{
		if(x < 0)
		{
			continue;
		}
		int y;
		for(y = 0; y < 64; y++)
		{
			if(y % 8 == 3 || y % 8 == 4 || y % 8 == 5)
			{
				m3_plot(x, 55 + y, RGB(21, 15, 5));
			}
			else
			{
				m3_plot(x, 55 + y, RGB(31, 29, 8));
			}
		}
	}
	//Right side
	for(x = danielx + 49; x < danielx + 49 + daniel_spd; x++)
	{
		if(x > 240)
		{
			continue;
		}
		int y;
		for(y = 0; y < 64; y++)
		{
			if(y % 8 == 3 || y % 8 == 4 || y % 8 == 5)
			{
				m3_plot(x, 55 + y, RGB(21, 15, 5));
			}
			else
			{
				m3_plot(x, 55 + y, RGB(31, 29, 8));
			}
		}
	}
}

void clear_target(int target_pos, int daniel_pos)
{
	draw_rect(232, 152, 8, 8, CLR_WHITE, 0, 0);
	COLOR patch[32][32];//Section of screen to redraw
	if((target_pos + 31 < daniel_pos) || (target_pos > daniel_pos + 48)) //Daniel and target do not overlap at all
	{
		for(int i = 0; i < 32; i++)
		{
			for(int j = 0; j < 32; j++)
			{
				if(i % 8 == 3 || i % 8 == 4 || i % 8 == 5)
				{
					patch[i][j] = RGB(21, 15, 5);
				}
				else
				{
					patch[i][j] = RGB(31, 29, 8);
				}
			}
		}
		m3_puts(232, 152, "1", CLR_BLACK, 0, 0);
	}
	else if((target_pos + 31 >= daniel_pos) && (target_pos < daniel_pos)) //Daniel and target overlap partially on left side
	{
		int space = daniel_pos - target_pos; //How much of the target is not overlapping with Daniel
		//(1) Add the background on the left
		//(2) Add the part of the daniel on the right
		for(int i = 0; i < 32; i++)
		{
			for(int j = 0; j < space; j++)
			{
				if(i % 8 == 3 || i % 8 == 4 || i % 8 == 5)
				{
					patch[i][j] = RGB(21, 15, 5);
				}
				else
				{
					patch[i][j] = RGB(31, 29, 8);
				}
			}
		}
		for(int i = 0; i < 32; i++)
		{
			for(int j = 0; j < 32 - space; j++)
			{
					patch[i][space + j] = daniel2[15 + i][j];
			}
		}
		m3_puts(232, 152, "2", CLR_BLACK, 0, 0);
	}
	else if((target_pos <= daniel_pos + 48) && (target_pos + 31 > daniel_pos + 48)) //Daniel and target overlap partially on right side
	{
		int space = 32 - (49 - (target_pos - daniel_pos)); //How much of the target is not overlapping with Daniel
		//(1) Add the part of the daniel on the left
		//(2) Add the background on the right
		for(int i = 0; i < 32; i++)
		{
			for(int j = 0; j < 32 - space; j++)
			{
					patch[i][j] = daniel2[15 + i][49 - space + j];
			}
		}
		for(int i = 0; i < 32; i++)
		{
			for(int j = 0; j < space; j++)
			{
				if(i % 8 == 3 || i % 8 == 4 || i % 8 == 5)
				{
					patch[i][j + 32 - space] = RGB(21, 15, 5);
				}
				else
				{
					patch[i][j + 32 - space] = RGB(31, 29, 8);
				}
			}
		}
		m3_puts(232, 152, "3", CLR_BLACK, 0, 0);
	}
	else if((target_pos >= daniel_pos) && (target_pos + 31 <= daniel_pos + 48))// Daniel and target overlap completely
	{
		for(int i = 0; i < 32; i++)
		{
			for(int j = 0; j < 32; j++)
			{
				patch[i][j] = daniel2[15][target_pos - daniel_pos + j];
			}
		}
		m3_puts(232, 152, "4", CLR_BLACK, 0, 0);
	}
	draw_img((COLOR*)patch, 32, 32, target_pos, 71, 0);
}