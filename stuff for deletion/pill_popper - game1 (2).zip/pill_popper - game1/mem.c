#include "toolbox.h"

u8 played, coins;

void get_coins()
{
	coins = save_mem[1] | (save_mem[2] << 8) | (save_mem[3] << 16) | (save_mem[4] < 24);
}

void save_coins(int amount)
{
	save_mem[1] = (amount & 255);
	save_mem[2] = ((amount >> 8) & 255);
	save_mem[3] = ((amount >> 16) & 255);
	save_mem[4] = ((amount >> 24) & 255);
}

void get_played()
{
	played = save_mem[0];
}

void set_played()
{
	save_mem[0] = 1;
}

void clear_mem()
{
	save_mem[0] = 0;
}