#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include "toolbox.h"
#include "images.c"
#include "pages.h"
#include "text.c"
#include "draw.c"
#include "keys.h"
#include "mem.c"

//Global variables for main to know when to trigger next function and what it is.
int in_func = 0;
//0 is home_screen() and 1 is game()
int next_func = 0;

//Global variables for which tutorial frame should be next
int in_tutorial;
int t_next = 1;


void delay(int frames) //approx. 60 fps
{
	int i;
	for(i = 0; i < frames; i++)
	{
		vid_vsync();
	}
}

void start_screen()
{
	draw_bg();
	txt_init_std();
	draw_rect(55, 25, 130, 100, RGB(31, 31, 19), 1, RGB(10, 6, 3));
	m3_puts(77, 40, "Pill Popper", CLR_BLACK, 1, 0x6739);
	draw_img((COLOR*)pill_small, 8, 16, 125, 36, 0x7E60);
	int brightness = 0;
	int going_down = 0;
	while(1)
	{
		m3_puts(77, 100, "PRESS START", RGB(0 + brightness, 0 + brightness, 0 + brightness), 0, 0);
		//Determine brightness and if text is getting darker or lighter
		if(brightness == 30)
		{
			going_down = 1;
		}
		if(brightness == 0)
		{
			going_down = 0;
		}
		if(going_down == 1)
		{
			brightness--;
		}
		else
		{
			brightness++;
		}
		
		//Waiting for START key
		key_poll();
		if(key_hit(KEY_START))
		{
			return;
		}
		if(key_held(KEY_A) && key_held(KEY_B) && key_held(KEY_L) && key_held(KEY_R))
		{
			clear_mem();
			m3_puts(0, 0, "CLEARED!", CLR_BLACK, 0, 0);
		}
		vid_vsync();
	};
	
	return;
}

void game()
{
	in_func = 1;
	//Initialize game constants
	int game_stage = 0; //0 = Determining power, 1 = Shooting Daniel, 2 = Game over
	int pills = 10;
	int lives = 3;
	int power_pos = 63;
	float power;//Decimal percentage
	int daniel_spd = 3;
	int daniel_pos = 96;
	int target_pos = 105;
	int target_counter = 4; //Target should be erased every 4 frames
	int timer = 60;
	int timer_counter = 180;
	
	draw_bg();
	draw_rect(1, 121, 239, 38, RGB(31, 31, 19), 1, RGB(10, 6, 3));
	draw_pills(pills);
	draw_rect(86, 131, 129, 18, 0x0000, 0, 0);
	draw_bar(power_pos);
	draw_rect(1, 1, 239, 12, RGB(31, 31, 19), 1, RGB(10, 6, 3));
	draw_lives(lives);
	m3_puts(3, 3, "NEXT PILL:", 0x0000, 0, 0);
	draw_timer(timer);
	draw_img((COLOR*)daniel, 49, 64, daniel_pos, 55, 0);
	draw_img((COLOR*)bulls_eye, 32, 32, target_pos, 71, 0);
	while(1)
	{
		if(game_stage == 0)
		{
			int dir = 0;//Direction of pointer; 0 = right, 1 = left
			int played = 0;
			while(1)
			{
				if(key_held(KEY_A))
				{
					played = 1;
					if(power_pos > 117)
					{
						dir = 1;
					}
					if(power_pos < 11)
					{
						dir = 0;
					}
					if(dir == 0)
					{
						power_pos += 4;
					}
					else
					{
						power_pos -= 4;
					}
					draw_bar(power_pos);
					vid_vsync();
				}
				if(key_released(KEY_A) && played == 1)
				{
					power = abs(power_pos - 63);
					power = floor(power * 100 + 0.5)/100;
					game_stage = 1;
					break;
				}
				key_poll();
			}
		}
		else if(game_stage == 1)
		{
			int dir = 0; //Direction of Daniel; 0 = right, 1 = left
			while(1)
			{
				target_counter -= 1;
				if(target_counter == 0)
				{
					target_counter = 4;
					clear_target(target_pos, daniel_pos); //Clear the target before its position is updated
				}
				if(daniel_pos + 48 >= 240 - daniel_spd)
				{
					dir = 1;
				}
				if(daniel_pos < daniel_spd)
				{
					dir = 0;
				}
				if(dir == 0)
				{
					daniel_pos += daniel_spd;
				}
				if(dir == 1)
				{
					daniel_pos -= daniel_spd;
				}
				key_poll();
				if(target_counter == 0)
				{
					if(KEY_DOWN_NOW(KEY_LEFT) && target_pos >= 5)
					{
						target_pos -= 5;
					}
					else if(KEY_DOWN_NOW(KEY_RIGHT) && target_pos + 31 <= 235)
					{
						target_pos += 5;
					}
				}
				clear_daniel(daniel_pos, daniel_spd);
				draw_timer(timer);
				draw_img((COLOR*)daniel2, 49, 64, daniel_pos, 55, 0);
				draw_img((COLOR*)bulls_eye, 32, 32, target_pos, 71, 0);
				timer_counter -= 1;
				timer = (int)floor(timer_counter / 3);
				if(timer_counter == 0)
				{
					timer_counter = 180;
					timer = 60;
				}
				vid_vsync();
			}
		}
	}
	next_func = 0;
	in_func = 0;
}

void home_screen()
{
	in_func = 1;
	draw_bg();
	draw_rect(55, 30, 130, 28, RGB(31, 31, 19), 1, RGB(10, 6, 3));
	m3_puts(77, 40, "Pill Popper", CLR_BLACK, 1, 0x6739);
	draw_img((COLOR*)pill_small, 8, 16, 125, 36, 0x7E60);
	draw_rect(55, 75, 130, 40, RGB(31, 31, 19), 1, RGB(10, 6, 3));
	draw_rect(90, 85, 60, 18, 0x6739, 1, 0x0000);
	draw_line(90, 102, 149, 102, 0x77BD);
	m3_puts(104, 90, "PLAY", CLR_BLACK, 0, 0);
	int brightness = 0;
	int going_down = 0;
	while(1)
	{
		m3_puts(104, 90, "PLAY", RGB(0 + brightness, 0 + brightness, 0 + brightness), 0, 0);
		//Determine brightness and if text is getting darker or lighter
		if(brightness == 30)
		{
			going_down = 1;
		}
		if(brightness == 0)
		{
			going_down = 0;
		}
		if(going_down == 1)
		{
			brightness--;
		}
		else
		{
			brightness++;
		}
		
		//Waiting for A key
		key_poll();
		if(key_hit(KEY_ACCEPT))
		{
			fade_black(7);
			delay(120);
			next_func = 1;
			in_func = 0;
			return;
		}
		vid_vsync();
	};
	
}

void t_page_1()
{
	fill_bg(RGB(0, 19, 25));
	draw_line(0, 20, 240, 20, CLR_WHITE);
	draw_line(0, 21, 240, 21, 0x4E73);
	m3_puts(15, 30, "Goal:\nYour job is to throw pills \ninto your annoying classmate \nDaniel's mouth.\n\n(DISCLAIMER: All persons in \nthe game are fictious and \nany similarity must be \naccidental.)", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)a_clr_button, 8, 8, 188, 6, 0);
	m3_puts(200, 6, "NEXT", CLR_WHITE, 1, 0x4E73);
	while(1)
	{
		key_poll();
		if(key_hit(KEY_A))
		{
			t_next = 2;
			return;
		}
	}
}

void t_page_2()
{
	fill_bg(RGB(0, 19, 25));
	draw_line(0, 20, 240, 20, CLR_WHITE);
	draw_line(0, 21, 240, 21, 0x4E73);
	m3_puts(15, 30, "Your pills come in\nboxes of 10.\n\nUse this power bar\nto determine the power of\nyour throw for this box.\n\n\n\nHold  to start the bar.\nLet go of  at the green\narea to get a high power.", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)pill_big, 16, 32, 188, 30, 0x001F);
	draw_rect(56, 96, 129, 18, 0x0000, 0, 0);
	int i;
	for(i = 0; i < 16; i++)
	{
		draw_img((COLOR*)accu_bar, 126, 1, 57, 97 + i, 0);
	}
	draw_img((COLOR*)pointer_icon, 16, 16, 111, 97, 0);
	draw_img((COLOR*)a_clr_button, 8, 8, 51, 120, 0);
	draw_img((COLOR*)a_clr_button, 8, 8, 91, 130, 0);
	draw_img((COLOR*)b_clr_button, 8, 8, 132, 6, 0);
	m3_puts(144, 6, "BACK", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)a_clr_button, 8, 8, 188, 6, 0);
	m3_puts(200, 6, "NEXT", CLR_WHITE, 1, 0x4E73);
	while(1)
	{
		key_poll();	
		if(key_hit(KEY_A))
		{
			t_next = 3;
			return;
		}
		if(key_hit(KEY_B))
		{
			t_next = 1;
			return;
		}
	}
}

void t_page_3()
{
	fill_bg(RGB(0, 19, 25));
	draw_line(0, 20, 240, 20, CLR_WHITE);
	draw_line(0, 21, 240, 21, 0x4E73);
	m3_puts(15, 30, "This is Daniel:\n\nWith a big mouth,\nit shouldn't be\nhard to throw\npills into his mouth.\n\nHowever, he moves around a\nlot. Just use this bull's\neye to aim.(LEFT and\nRIGHT keys.) Pills\nare shot every 3 secs.", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)daniel, 49, 64, 176, 25, 0);
	draw_img((COLOR*)bulls_eye, 32, 32, 190, 123, 0);
	draw_img((COLOR*)b_clr_button, 8, 8, 132, 6, 0);
	m3_puts(144, 6, "BACK", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)a_clr_button, 8, 8, 188, 6, 0);
	m3_puts(200, 6, "NEXT", CLR_WHITE, 1, 0x4E73);
	while(1)
	{
		key_poll();
		if(key_hit(KEY_A))
		{
			t_next = 4;
			return;
		}
		if(key_hit(KEY_B))
		{
			t_next = 2;
			return;
		}
	}
}

void t_page_4()
{
	fill_bg(RGB(0, 19, 25));
	draw_line(0, 20, 240, 20, CLR_WHITE);
	draw_line(0, 21, 240, 21, 0x4E73);
	m3_puts(15, 30, "However, you should be\ncautioned that he moves\nfaster and faster.\n\nThese hearts represent\nyour life count:\n\n\nYou start with 3 lives.\nYou lose one every time\nyou miss Daniel's mouth.", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)heart_1, 9, 8, 75, 95, 0);
	draw_img((COLOR*)heart_1, 9, 8, 87, 95, 0);
	draw_img((COLOR*)heart_2, 9, 8, 99, 95, 0);
	draw_img((COLOR*)b_clr_button, 8, 8, 132, 6, 0);
	m3_puts(144, 6, "BACK", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)a_clr_button, 8, 8, 188, 6, 0);
	m3_puts(200, 6, "NEXT", CLR_WHITE, 1, 0x4E73);
	while(1)
	{
		key_poll();
		if(key_hit(KEY_A))
		{
			t_next = 5;
			return;
		}
		if(key_hit(KEY_B))
		{
			t_next = 3;
			return;
		}
	}
}

void t_page_5()
{
	fill_bg(RGB(0, 19, 25));
	draw_line(0, 20, 240, 20, CLR_WHITE);
	draw_line(0, 21, 240, 21, 0x4E73);
	m3_puts(15, 30, "To sum up:\n  1. Determine the power\n  2. Aim and shoot\n  3. Have fun\n\nWell, that's all there\nis to the game, and:\n\n\n    HAPPY PILL POPPING!", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)b_clr_button, 8, 8, 132, 6, 0);
	m3_puts(144, 6, "BACK", CLR_WHITE, 1, 0x4E73);
	draw_img((COLOR*)a_clr_button, 8, 8, 188, 6, 0);
	m3_puts(200, 6, "NEXT", CLR_WHITE, 1, 0x4E73);
	while(1)
	{
		key_poll();
		if(key_hit(KEY_A))
		{
			in_tutorial = 0;
			return;
		}
		if(key_hit(KEY_B))
		{
			t_next = 4;
			return;
		}
	}
}

void tutorial()
{
	in_tutorial = 1;
	while(in_tutorial == 1)
	{
		switch(t_next)
		{
			case 1:
				t_page_1();
				break;
				
			case 2:
				t_page_2();
				break;
				
			case 3:
				t_page_3();
				break;
				
			case 4:
				t_page_4();
				break;
				
			case 5:
				t_page_5();
				break;
		}
	}
}

int main()
{
	REG_DISPCNT = DCNT_MODE3 | DCNT_BG2;
	start_screen();
	fade_black(7);
	delay(100);
	get_played();
	if(played != 1)
	{
		tutorial();
		set_played();
	}
	while(1)
	{
		if(in_func == 0)
		{
			if(next_func == 0)
			{
				home_screen();
			}
			if(next_func == 1)
			{
				game();
			}
		}
	}
	return 0;
}